# webtech-prj-sciencedb
Create e knowledge base of scientific articles

# Descriere proiect

Proiectul are ca scop crearea unei aplicatii web care deserveste la comandarea de produse si la stocarea lor pentru un restaurant.
Clientul va putea accesa aceasta aplicatie din restaurant, putand comanda in timp real in urma consultarii meniului, preparatele dorite.
Pentru aceasta in proiect va exista o interfata pentru client.

Pentru gestionarea produselor si a entitatilor restaurantului va exista o baza de date.

# Entitati
Produs
* id
* nume
* cantitate
* pret

Preparat
* id_preparat
* nume_preparat
* cantitate_preparat
* alergeni
* descriere
* 

# Tehologii

* NodeJs 
* NodeAdmin
* MySQL

# ToDo
* install mysql [done]
* install node admin [done]
* create the database [done]
* install sequelize [done]
* create a model [done]
* list preparate [done]

# Resources
* https://community.c9.io/t/setting-up-mysql/1718
* https://www.npmjs.com/package/nodeadmin
* 


