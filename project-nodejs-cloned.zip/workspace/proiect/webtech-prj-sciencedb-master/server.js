var express = require("express");
var bodyParser = require("body-parser");
var cors = require("cors");
var Sequelize = require("sequelize");
var fs = require('fs');

var sequelize = new Sequelize('restaurant', 'elenaiaru', '', {
   dialect: 'mysql',
   port: 3306
});

var Produs = sequelize.define('PRODUSE', {
 
  nume: {
    type: Sequelize.STRING,
    field: 'nume'
  },
  cantitate: {
    type: Sequelize.STRING,
    field: 'cantitate'
  },
  pret: {
    type: Sequelize.STRING,
    field: 'pret'
  },
  
}, {
  freezeTableName: true, // Model tableName will be the same as the model name
  timestamps: false
});


var Preparat = sequelize.define('PREPARATE', {
 
  nume_preparat: {
    type: Sequelize.STRING,
    field: 'nume_preparat'
  },
  cantitate_preparat: {
    type: Sequelize.STRING,
    field: 'cantitate_preparat'
  },
  alergeni: {
    type: Sequelize.STRING,
    field: 'alergeni'
  },
  descriere: {
    type: Sequelize.STRING,
    field: 'descriere'
  },
  
}, {
  freezeTableName: true, // Model tableName will be the same as the model name
  timestamps: false
});





var Meniu= sequelize.define('MENIU', {
 
  
  nume_meniu: {
    type: Sequelize.STRING,
    field: 'nume_meniu'
  },
  
  id_preparat: {
    type: Sequelize.STRING,
    field: 'id_preparat'
  },
  
}, {
  freezeTableName: true, // Model tableName will be the same as the model name
  timestamps: false
});





var Comentariu = sequelize.define('FEEDBACK', {
 
  comentariu: {
    type: Sequelize.TEXT,
    field: 'comentariu'
  },
  nume_client: {
    type: Sequelize.TEXT,
    field: 'nume_client'
  },
  
}, {
  freezeTableName: true, // Model tableName will be the same as the model name
  timestamps: false
});




var app = express();
app.use(bodyParser.json());
app.use(cors());


var nodeadmin = require('nodeadmin');
app.use(nodeadmin(app));
app.use(express.static(__dirname + '/node_modules'));

// REST methods
app.get('/produse', function(req,res){
    /*global Author*/
    Produs.findAll().then(function(produse){
        res.status(200).send(produse);
    });
});

app.get('/preparate', function(req,res){
    
    Preparat.findAll().then(function(preparate){
        res.status(200).send(preparate);
    });
});

app.get('/preparate/:id', function(req,res){
    Produs.findAll({
        where: {
            id: req.params.id
        }
    }).then(function(preparat){
        if(preparat.length > 0) {
            res.status(200).send(preparat[0]);
        } else {
            res.status(404).send();
        }
    })
});


app.get('/adaugaComentariu', function(req,res){

    Comentariu.create({comentariu:req.query.comentariu,nume_client:req.query.numeClient}).then(function(){
        res.status(201).send('felicitari ai adaugat un comentariu');
    }).catch(function(err){
        console.warn(err);
    });
});


app.get('/meniuri', function(req,res){
    
    Meniu.findAll().then(function(meniuri){
        res.status(200).send(meniuri);
    });
});

app.get('/meniuri/:id', function(req,res){
    Meniu.findAll({
        where: {
            id: req.params.id
        }
    }).then(function(meniu){
        if(meniu.length > 0) {
            res.status(200).send(meniu[0]);
        } else {
            res.status(404).send();
        }
    })
});







app.get('/', function(req,res){
    res.status(200).send('hellow');
});

// app.post('/produse', function(req,res) {
//   Produs.create(req.body).then(function(){
//         res.status(201).send();
//     }).catch(function(err){
//         console.warn(err);
//     });
// });


app.get('/index.html',function(req,res){
    fs.readFile('index.html', function (err, data) {
        if (err) {
            console.log(err);
            res.writeHead(404, {'Content-Type': 'text/html'});
        }else{	
            res.writeHead(200, {'Content-Type': 'text/html'});	
            res.write(data.toString());		
        }
        res.end();
   });   
});


app.get('/restaurant.html',function(req,res){
    fs.readFile('restaurant.html', function (err, data) {
        if (err) {
            console.log(err);
            res.writeHead(404, {'Content-Type': 'text/html'});
        }else{	
            res.writeHead(200, {'Content-Type': 'text/html'});	
            res.write(data.toString());		
        }
        res.end();
   });   
});

app.get('/home',function(req,res){
    console.log('a intrat aici');
            res.writeHead(200, {'Content-Type': 'text/html'});	
            res.write('<p>salut</p>');	
            res.end();
 
});

app.delete('/produse/:id', function(req,res){
    
});

app.put('/produse/:id', function(req,res){
    
});

app.delete('/preparate/:id', function(req,res){
    
});
app.put('/preparate/:id', function(req,res){
    
});




app.delete('/meniuri/:id', function(req,res){
    
});
app.put('/meniuri/:id', function(req,res){
    
});

app.listen(8080);